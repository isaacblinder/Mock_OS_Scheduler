Isaac Blinder
10/10/17

For this project I created a two-pass linker.

Compiling the code: (Mac)
The program accepts one argument, the text doc (the input).
For simplicity, make sure the text doc is in the same folder as the project.

1) Navigate to the project folder using cd
2) Compile using    javac Scheduler.java
3) run using    java Scheduler nameOfInput.txt  
or use java Scheduler --verbose nameOfInput.txt  for debugger information

The output should be printed to the terminal.